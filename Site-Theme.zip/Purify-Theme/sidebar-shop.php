<div id="sidebar" class="col-md-3 hidden-sm-xs">
	<?php dynamic_sidebar( 'shop' ); ?>
</div>