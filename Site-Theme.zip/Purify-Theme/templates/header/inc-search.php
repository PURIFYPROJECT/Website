<div class="module widget-wrap search-widget-wrap left">
    <div class="search">
        <a href="#"><i class="ti-search"></i></a>
        <span class="title"><?php esc_html_e( 'Search Site', 'roneous' ); ?></span>
    </div>
    <div class="widget-inner">
        <?php echo get_search_form(); ?>
    </div>
</div>