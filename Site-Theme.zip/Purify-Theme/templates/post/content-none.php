<p class="lead"><?php esc_html_e( 'Sorry, but nothing matched your search. Please try again with some different keywords.', 'roneous' ); ?></p>
<?php get_search_form(); ?>