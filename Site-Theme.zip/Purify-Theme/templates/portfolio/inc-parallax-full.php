<?php 
global $post;
$externalUrl    = isset($post->ID) ? get_post_meta( $post->ID, '_tlg_portfolio_external_url', 1 ) : '';
$target         = $externalUrl && get_post_meta( $post->ID, '_tlg_portfolio_url_new_window', 1 )  ? '_blank' : '_self';
$rel            = $externalUrl && get_post_meta( $post->ID, '_tlg_portfolio_url_nofollow', 1 )  ? 'nofollow' : '';
$portfolioLink  = $externalUrl ? $externalUrl : get_permalink();
?>
<section class="fullscreen image-bg overlay parallax project-parallax">
    <div class="background-content">
        <?php the_post_thumbnail( 'full', array('class' => 'background-image') ); ?>
        <div class="background-overlay"></div>
    </div>
    <div class="container vertical-alignment text-center">
        <?php the_title('<h2 class="xs-text-mobile uppercase mb8">', '</h2><h4 class="s-text-mobile uppercase">'. roneous_the_terms( 'portfolio_category', ' / ', 'name' ) .'</h4>'); ?>
        <a class="btn btn-white btn-lg btn-rounded mt16 mb0" href="<?php echo esc_url( $portfolioLink ); ?>" target="<?php echo esc_attr($target); ?>" rel="<?php echo esc_attr($rel); ?>"><?php esc_html_e( 'Open Project','roneous' ); ?></a>
    </div>
</section>