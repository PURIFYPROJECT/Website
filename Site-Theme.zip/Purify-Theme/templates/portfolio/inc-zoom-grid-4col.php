<?php 
global $post;
$externalUrl    = isset($post->ID) ? get_post_meta( $post->ID, '_tlg_portfolio_external_url', 1 ) : '';
$target         = $externalUrl && get_post_meta( $post->ID, '_tlg_portfolio_url_new_window', 1 )  ? '_blank' : '_self';
$rel            = $externalUrl && get_post_meta( $post->ID, '_tlg_portfolio_url_nofollow', 1 )  ? 'nofollow' : '';
$portfolioLink  = $externalUrl ? $externalUrl : get_permalink();
?>
<div class="col-md-3 col-sm-6 project box-zoom" data-filter="<?php echo esc_html__( 'All', 'roneous' ).','.roneous_the_terms( 'portfolio_category', ',', 'name' ); ?>" 
		data-groups='["<?php echo roneous_the_terms( 'portfolio_category', '","', 'slug' ); ?>"]'>
    <div class="box-inner">
        <div class="box-inner__i">
            <div class="box-pic">
                <?php the_post_thumbnail( 'roneous_box', array('class' => 'background-image') ); ?>
                <div class="box-mask">
                    <a href="<?php echo esc_url( $portfolioLink ); ?>" target="<?php echo esc_attr($target); ?>" rel="<?php echo esc_attr($rel); ?>" >
                        <div class="mask-content text-center">
                            <h2 class="mask-content__title title-small"><?php the_title(); ?></h2>
                            <div class="mask-content__meta"><?php echo roneous_the_terms( 'portfolio_category', ' / ', 'name' ); ?></div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>