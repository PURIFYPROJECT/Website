<?php 
global $post;
$externalUrl    = isset($post->ID) ? get_post_meta( $post->ID, '_tlg_portfolio_external_url', 1 ) : '';
$target         = $externalUrl && get_post_meta( $post->ID, '_tlg_portfolio_url_new_window', 1 )  ? '_blank' : '_self';
$rel            = $externalUrl && get_post_meta( $post->ID, '_tlg_portfolio_url_nofollow', 1 )  ? 'nofollow' : '';
$portfolioLink  = $externalUrl ? $externalUrl : get_permalink();
?>
<section class="image-bg bg-dark parallax project-parallax overlay z-index pt64 pb64">
    <div class="background-content">
        <?php the_post_thumbnail( 'full', array('class' => 'background-image') ); ?>
        <div class="background-overlay"></div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center">
                <a href="<?php echo esc_url( $portfolioLink ); ?>" target="<?php echo esc_attr($target); ?>" rel="<?php echo esc_attr($rel); ?>">
                    <?php the_title('<h4 class="xs-text-mobile uppercase mb8">', '</h4><h6 class="s-text-mobile uppercase">'. roneous_the_terms( 'portfolio_category', ' / ', 'name' ) .'</h6>'); ?>
                </a>
            </div>
        </div>
    </div>
</section>